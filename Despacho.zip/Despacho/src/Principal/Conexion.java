package Principal;


import java.sql.*;



public class Conexion {


   Connection conectar = null;

    public Connection conexion() {
    	
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		conectar = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/olna","root","root");
    		if(conectar!=null) {
    			System.out.println("Conexion establecida");
    		}
    		}catch (ClassNotFoundException | SQLException e) {
    			System.out.println("Error al conectar" + e);
    		}
        return conectar;
    }
    
   
}

